# 📱 بناء تطبيق Android APK

تم إعداد Capacitor بالكامل! اتبع هذه الخطوات على جهازك لبناء ملف APK.

## ✅ المتطلبات

1. **Node.js** (v18+) و **Bun** أو **npm**
2. **Android Studio** — [تحميل من هنا](https://developer.android.com/studio)
3. **Java JDK 17+** (يأتي مع Android Studio)

---

## 🚀 خطوات البناء

### 1) استنساخ المشروع وتثبيت الحزم
```bash
git clone <رابط-مشروعك>
cd <اسم-المشروع>
bun install
```

### 2) بناء نسخة الويب
```bash
bun run build
```

### 3) إضافة منصة Android (أول مرة فقط)
```bash
npx cap add android
```

### 4) مزامنة الملفات مع مشروع Android
```bash
npx cap sync android
```

### 5) فتح المشروع في Android Studio
```bash
npx cap open android
```

---

## 🔨 توليد ملف APK داخل Android Studio

1. انتظر حتى ينتهي **Gradle Sync** (قد يستغرق 5-10 دقائق أول مرة)
2. من القائمة العلوية: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
3. عند انتهاء البناء، اضغط **locate** للوصول إلى ملف APK
4. المسار: `android/app/build/outputs/apk/debug/app-debug.apk`

---

## 📲 تثبيت APK على هاتفك

1. انقل الملف `app-debug.apk` إلى هاتفك
2. فعّل **Install from Unknown Sources** في إعدادات الأمان
3. اضغط على الملف لتثبيته
4. افتح التطبيق وستجد البث يعمل بشكل مباشر! ⚡

---

## 🎯 لماذا سيشتغل البث الآن؟

تم تفعيل الإعدادات التالية في `capacitor.config.ts`:
- ✅ `cleartext: true` — السماح بحركة HTTP
- ✅ `allowMixedContent: true` — السماح بمحتوى مختلط
- ✅ `androidScheme: 'http'` — استخدام بروتوكول HTTP

هذه الإعدادات تتجاوز قيود المتصفح وتسمح للتطبيق بتشغيل روابط `http://` مباشرة.

---

## 🔄 عند تحديث التطبيق

كل مرة تعدّل الكود:
```bash
bun run build
npx cap sync android
```
ثم أعد بناء APK من Android Studio.

---

## 💡 نصائح

- لإصدار **Release APK** موقّع (للنشر): استخدم **Build → Generate Signed Bundle / APK**
- أيقونة التطبيق: استبدل الملفات في `android/app/src/main/res/mipmap-*`
- اسم التطبيق: عدّل `appName` في `capacitor.config.ts`

---

استمتع بمشاهدة beIN Sports! ⚽🏆
