import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { Calendar, Clock, MapPin, Trophy } from "lucide-react";
import { Header } from "@/components/Header";

interface Match {
  idEvent: string;
  strEvent: string;
  strHomeTeam: string;
  strAwayTeam: string;
  strLeague: string;
  strVenue?: string;
  dateEvent: string;
  strTime?: string;
  strThumb?: string;
  strHomeTeamBadge?: string;
  strAwayTeamBadge?: string;
}

async function fetchMatches(): Promise<Match[]> {
  // TheSportsDB free public endpoint — no API key needed
  const leagues = ["English Premier League", "Spanish La Liga", "UEFA Champions League"];
  const results: Match[] = [];

  for (const league of leagues) {
    try {
      const res = await fetch(
        `https://www.thesportsdb.com/api/v1/json/3/eventsnextleague.php?id=${getLeagueId(league)}`,
      );
      if (!res.ok) continue;
      const data = (await res.json()) as { events: Match[] | null };
      if (data.events) results.push(...data.events.slice(0, 6));
    } catch {
      /* skip */
    }
  }

  return results.slice(0, 18);
}

function getLeagueId(name: string): string {
  const map: Record<string, string> = {
    "English Premier League": "4328",
    "Spanish La Liga": "4335",
    "UEFA Champions League": "4480",
  };
  return map[name] ?? "4328";
}

export const Route = createFileRoute("/matches")({
  head: () => ({
    meta: [
      { title: "Live Matches · beIN Live" },
      {
        name: "description",
        content: "Upcoming live football matches from Premier League, La Liga and Champions League.",
      },
      { property: "og:title", content: "Live Matches · beIN Live" },
    ],
  }),
  loader: () => fetchMatches(),
  pendingComponent: PendingMatches,
  errorComponent: ErrorMatches,
  component: MatchesPage,
});

function PendingMatches() {
  return (
    <>
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="mb-10">
          <div className="h-4 w-32 animate-pulse rounded bg-muted" />
          <div className="mt-3 h-12 w-72 animate-pulse rounded bg-muted" />
        </div>
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-44 animate-pulse rounded-2xl glass-card" />
          ))}
        </div>
      </main>
    </>
  );
}

function ErrorMatches({ error }: { error: Error }) {
  const router = useRouter();
  return (
    <>
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-md text-center">
          <h2 className="font-display text-2xl font-bold uppercase text-destructive">
            Cannot load matches
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">{error.message}</p>
          <button
            onClick={() => router.invalidate()}
            className="mt-6 rounded-full gradient-violet px-6 py-3 font-display text-sm font-semibold uppercase tracking-wider text-white shadow-glow"
          >
            Retry
          </button>
        </div>
      </main>
    </>
  );
}

function formatDate(dateStr: string, timeStr?: string): { date: string; time: string } {
  try {
    const d = new Date(`${dateStr}T${timeStr ?? "00:00:00"}`);
    return {
      date: d.toLocaleDateString("en-US", { month: "short", day: "numeric", weekday: "short" }),
      time: timeStr ? d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }) : "TBA",
    };
  } catch {
    return { date: dateStr, time: timeStr ?? "TBA" };
  }
}

function MatchesPage() {
  const matches = Route.useLoaderData() as Match[];

  // Group by league
  const grouped: Record<string, Match[]> = {};
  for (const m of matches) {
    const key = m.strLeague || "Other";
    (grouped[key] ??= []).push(m);
  }

  return (
    <>
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
        <header className="mb-10 animate-fade-in-up">
          <span className="font-display text-xs font-semibold uppercase tracking-[0.3em] text-primary-glow">
            Live Schedule
          </span>
          <h1 className="mt-2 font-display text-4xl font-black uppercase tracking-tight sm:text-6xl">
            <span className="text-foreground">Upcoming </span>
            <span className="text-gradient">Matches</span>
          </h1>
          <p className="mt-4 max-w-2xl text-base text-muted-foreground">
            The biggest fixtures from Europe's top leagues. Tune in to the right beIN channel and
            don't miss a moment.
          </p>
        </header>

        {Object.keys(grouped).length === 0 && (
          <div className="rounded-3xl glass-card p-12 text-center">
            <Trophy className="mx-auto h-12 w-12 text-muted-foreground/50" />
            <p className="mt-4 font-display text-lg uppercase tracking-wider">
              No upcoming matches found
            </p>
            <p className="mt-2 text-sm text-muted-foreground">Check back soon.</p>
          </div>
        )}

        {Object.entries(grouped).map(([league, items], idx) => (
          <section key={league} className="mb-12 animate-fade-in-up" style={{ animationDelay: `${idx * 0.1}s` }}>
            <div className="mb-5 flex items-center gap-3">
              <Trophy className="h-5 w-5 text-gold" />
              <h2 className="font-display text-xl font-bold uppercase tracking-wider text-foreground sm:text-2xl">
                {league}
              </h2>
              <div className="h-px flex-1 bg-gradient-to-r from-border to-transparent" />
            </div>
            <div className="stagger grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
              {items.map((m) => {
                const { date, time } = formatDate(m.dateEvent, m.strTime);
                return (
                  <article
                    key={m.idEvent}
                    className="group relative overflow-hidden rounded-2xl glass-card hover-lift bg-noise"
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                    <div className="relative p-5">
                      <div className="flex items-center justify-between">
                        <span className="rounded-full bg-primary/15 px-2.5 py-0.5 font-display text-[10px] font-bold uppercase tracking-widest text-primary-glow ring-1 ring-primary/30">
                          {date}
                        </span>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          <span className="font-mono">{time}</span>
                        </div>
                      </div>

                      <div className="mt-5 flex items-center justify-between gap-3">
                        <Team
                          name={m.strHomeTeam}
                          badge={m.strHomeTeamBadge}
                          align="left"
                        />
                        <span className="font-display text-2xl font-black text-muted-foreground">
                          VS
                        </span>
                        <Team
                          name={m.strAwayTeam}
                          badge={m.strAwayTeamBadge}
                          align="right"
                        />
                      </div>

                      {m.strVenue && (
                        <div className="mt-5 flex items-center gap-1.5 truncate text-xs text-muted-foreground">
                          <MapPin className="h-3 w-3 shrink-0" />
                          <span className="truncate">{m.strVenue}</span>
                        </div>
                      )}
                    </div>
                  </article>
                );
              })}
            </div>
          </section>
        ))}

        <div className="mt-12 flex justify-center">
          <Link
            to="/"
            className="inline-flex items-center gap-2 rounded-full gradient-violet px-8 py-3.5 font-display text-sm font-semibold uppercase tracking-wider text-white shadow-glow transition-all hover:scale-105 hover:shadow-glow-lg"
          >
            <Calendar className="h-4 w-4" />
            Back to Channels
          </Link>
        </div>
      </main>
    </>
  );
}

function Team({
  name,
  badge,
  align,
}: {
  name: string;
  badge?: string;
  align: "left" | "right";
}) {
  return (
    <div className={`flex flex-1 items-center gap-2 ${align === "right" ? "flex-row-reverse text-right" : ""}`}>
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full glass">
        {badge ? (
          <img
            src={badge}
            alt={name}
            className="h-9 w-9 object-contain"
            loading="lazy"
            width={36}
            height={36}
          />
        ) : (
          <Trophy className="h-5 w-5 text-muted-foreground" />
        )}
      </div>
      <span className="font-display text-xs font-bold uppercase leading-tight tracking-wide text-foreground line-clamp-2">
        {name}
      </span>
    </div>
  );
}
