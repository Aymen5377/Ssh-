import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="relative flex min-h-screen items-center justify-center px-4">
      <div className="relative max-w-md text-center animate-fade-in">
        <h1 className="font-display text-[8rem] font-black leading-none text-gradient">404</h1>
        <h2 className="mt-2 font-display text-2xl font-bold uppercase tracking-wider text-foreground">
          Channel Not Found
        </h2>
        <p className="mt-3 text-sm text-muted-foreground">
          The page you're looking for is off-air.
        </p>
        <div className="mt-8">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-full gradient-violet px-8 py-3 font-display text-sm font-semibold uppercase tracking-wider text-white shadow-glow transition-all hover:scale-105 hover:shadow-glow-lg"
          >
            Back to Channels
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "beIN Live — Premium Sports Streaming" },
      {
        name: "description",
        content:
          "Watch beIN Sports channels live with cinematic quality. Premium football, tennis, motorsports and more.",
      },
      { name: "theme-color", content: "#0a0014" },
      { property: "og:title", content: "beIN Live — Premium Sports Streaming" },
      { property: "og:description", content: "Cinematic live sports streaming experience." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (
    <div className="relative z-10 min-h-screen">
      <Outlet />
    </div>
  );
}
