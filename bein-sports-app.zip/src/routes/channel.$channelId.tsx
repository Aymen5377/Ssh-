import { createFileRoute, Link, notFound, useRouter } from "@tanstack/react-router";
import { ArrowLeft, ChevronRight } from "lucide-react";
import { Header } from "@/components/Header";
import { HlsPlayer } from "@/components/HlsPlayer";
import { ChannelCard } from "@/components/ChannelCard";
import { channels, getChannelById } from "@/lib/channels";
import cosmicBg from "@/assets/design-3-cosmic-violet.jpg";

export const Route = createFileRoute("/channel/$channelId")({
  loader: ({ params }) => {
    const channel = getChannelById(params.channelId);
    if (!channel) throw notFound();
    return { channel };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData ? `${loaderData.channel.fullName} · Live` : "Channel" },
      {
        name: "description",
        content: loaderData
          ? `Watch ${loaderData.channel.fullName} live — ${loaderData.channel.description}`
          : "",
      },
    ],
  }),
  notFoundComponent: NotFound,
  errorComponent: ({ error }) => {
    const router = useRouter();
    return (
      <div className="flex min-h-screen items-center justify-center px-4">
        <div className="text-center">
          <p className="font-display text-lg text-destructive">{error.message}</p>
          <button
            onClick={() => router.invalidate()}
            className="mt-4 rounded-full gradient-violet px-6 py-2 text-sm font-semibold text-white"
          >
            Retry
          </button>
        </div>
      </div>
    );
  },
  component: ChannelPage,
});

function NotFound() {
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="text-center">
        <h1 className="font-display text-4xl font-black uppercase text-gradient">
          Channel Off-Air
        </h1>
        <Link
          to="/"
          className="mt-6 inline-flex rounded-full gradient-violet px-6 py-3 font-display text-sm font-semibold uppercase text-white shadow-glow"
        >
          Back to Channels
        </Link>
      </div>
    </div>
  );
}

function ChannelPage() {
  const { channel } = Route.useLoaderData();
  const otherChannels = channels.filter((c) => c.id !== channel.id).slice(0, 8);

  return (
    <>
      <Header />

      {/* Background atmosphere */}
      <div className="pointer-events-none fixed inset-0 -z-10 opacity-30">
        <img
          src={cosmicBg}
          alt=""
          className="h-full w-full object-cover"
          width={1920}
          height={1080}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/85 to-background" />
      </div>

      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-10 lg:px-8">
        {/* Breadcrumb */}
        <div className="mb-6 flex items-center gap-2 text-xs">
          <Link
            to="/"
            className="flex items-center gap-1.5 rounded-full glass px-3 py-1.5 font-display uppercase tracking-wider text-muted-foreground transition-all hover:text-foreground"
          >
            <ArrowLeft className="h-3 w-3" />
            Channels
          </Link>
          <ChevronRight className="h-3 w-3 text-muted-foreground" />
          <span className="font-display uppercase tracking-wider text-primary-glow">
            {channel.fullName}
          </span>
        </div>

        {/* Player */}
        <div className="animate-fade-in-up">
          <HlsPlayer src={channel.streamUrl} title={channel.fullName} />
        </div>

        {/* Channel info */}
        <div className="mt-8 grid gap-6 lg:grid-cols-[2fr_1fr]">
          <div className="animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-2 rounded-full bg-live/15 px-3 py-1 ring-1 ring-live/30">
                <span className="live-dot" />
                <span className="font-display text-[10px] font-bold uppercase tracking-[0.2em] text-live">
                  On Air
                </span>
              </span>
              <span className="font-display text-xs font-semibold uppercase tracking-[0.25em] text-muted-foreground">
                {channel.category} · HD
              </span>
            </div>
            <h1 className="mt-4 font-display text-4xl font-black uppercase tracking-tight sm:text-5xl">
              {channel.fullName}
            </h1>
            <p className="mt-3 text-lg text-muted-foreground">{channel.description}</p>
          </div>

          <div
            className="glass-card animate-fade-in-up rounded-2xl p-6"
            style={{ animationDelay: "0.2s" }}
          >
            <div className="flex items-baseline gap-3">
              <span className="font-display text-6xl font-black text-gradient">
                {String(channel.number).padStart(2, "0")}
              </span>
              <span className="font-display text-sm uppercase tracking-widest text-muted-foreground">
                Channel No.
              </span>
            </div>
            <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
              Premium live broadcast streamed in real-time. Use the controls above to play, mute,
              switch to picture-in-picture or go fullscreen.
            </p>
          </div>
        </div>

        {/* More channels */}
        <section className="mt-16">
          <div className="mb-6 flex items-end justify-between">
            <div>
              <span className="font-display text-xs font-semibold uppercase tracking-[0.3em] text-primary-glow">
                Keep Watching
              </span>
              <h2 className="mt-2 font-display text-2xl font-black uppercase tracking-tight sm:text-3xl">
                More Channels
              </h2>
            </div>
            <Link
              to="/"
              className="hidden items-center gap-1 font-display text-xs font-semibold uppercase tracking-wider text-primary-glow hover:text-foreground sm:inline-flex"
            >
              View All <ChevronRight className="h-3 w-3" />
            </Link>
          </div>
          <div className="stagger grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {otherChannels.map((c) => (
              <ChannelCard key={c.id} channel={c} />
            ))}
          </div>
        </section>
      </main>

      <footer className="mt-12 border-t border-border/40 px-4 py-8 text-center sm:px-6">
        <p className="font-display text-xs uppercase tracking-[0.3em] text-muted-foreground">
          beIN Live · Premium Sports Streaming
        </p>
      </footer>
    </>
  );
}
