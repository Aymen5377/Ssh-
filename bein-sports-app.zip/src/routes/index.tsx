import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { Search, Sparkles, Tv2, ChevronRight } from "lucide-react";
import { Header } from "@/components/Header";
import { ChannelCard } from "@/components/ChannelCard";
import { channels } from "@/lib/channels";
import heroImage from "@/assets/design-1-royal-noir.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "beIN Live — All Channels" },
      {
        name: "description",
        content: "Browse and watch all beIN Sports channels live in cinematic quality.",
      },
      { property: "og:title", content: "beIN Live — All Channels" },
      { property: "og:image", content: heroImage },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<string>("All");

  const categories = useMemo(() => {
    const set = new Set(channels.map((c) => c.category));
    return ["All", ...Array.from(set)];
  }, []);

  const filtered = useMemo(() => {
    return channels.filter((c) => {
      const matchesCategory = activeCategory === "All" || c.category === activeCategory;
      const q = query.trim().toLowerCase();
      const matchesQuery =
        !q ||
        c.fullName.toLowerCase().includes(q) ||
        c.description.toLowerCase().includes(q) ||
        String(c.number).includes(q);
      return matchesCategory && matchesQuery;
    });
  }, [query, activeCategory]);

  const featured = channels[0];

  return (
    <>
      <Header />

      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <img
            src={heroImage}
            alt=""
            className="h-full w-full object-cover opacity-50"
            width={1920}
            height={1080}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/80 to-background" />
        </div>

        <div className="mx-auto max-w-7xl px-4 pb-12 pt-16 sm:px-6 sm:pb-16 sm:pt-24 lg:px-8 lg:pt-32">
          <div className="max-w-3xl animate-fade-in-up">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full glass px-4 py-1.5">
              <Sparkles className="h-3.5 w-3.5 text-primary-glow" />
              <span className="font-display text-[11px] font-semibold uppercase tracking-[0.25em] text-primary-glow">
                Premium · Live · Always On
              </span>
            </div>

            <h1 className="font-display text-5xl font-black uppercase leading-[0.95] tracking-tight sm:text-6xl lg:text-7xl">
              <span className="block text-foreground">The Game</span>
              <span className="block text-gradient">Lives Here.</span>
            </h1>

            <p className="mt-6 max-w-xl text-base text-muted-foreground sm:text-lg">
              Stream {channels.length} premium beIN Sports channels in pristine quality.
              Football, tennis, motorsports, combat — every match, every moment.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link
                to="/channel/$channelId"
                params={{ channelId: featured.id }}
                className="group inline-flex items-center gap-3 rounded-full gradient-violet px-7 py-3.5 font-display text-sm font-semibold uppercase tracking-wider text-white shadow-glow transition-all hover:scale-105 hover:shadow-glow-lg"
              >
                <Tv2 className="h-4 w-4" />
                Watch Now
                <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <a
                href="#channels"
                className="inline-flex items-center gap-2 rounded-full glass px-7 py-3.5 font-display text-sm font-semibold uppercase tracking-wider text-foreground transition-all hover:bg-white/10"
              >
                Browse Channels
              </a>
            </div>
          </div>

          {/* Stats */}
          <div className="mt-14 grid grid-cols-3 gap-4 sm:mt-20 sm:max-w-2xl sm:gap-6">
            {[
              { value: channels.length, label: "Channels" },
              { value: "24/7", label: "Live" },
              { value: "HD", label: "Quality" },
            ].map((stat, i) => (
              <div
                key={stat.label}
                className="glass rounded-2xl p-4 text-center animate-fade-in-up sm:p-6"
                style={{ animationDelay: `${0.2 + i * 0.1}s` }}
              >
                <div className="font-display text-2xl font-black text-gradient sm:text-4xl">
                  {stat.value}
                </div>
                <div className="mt-1 text-[10px] uppercase tracking-[0.2em] text-muted-foreground sm:text-xs">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CHANNELS */}
      <section id="channels" className="relative mx-auto max-w-7xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8">
        <div className="mb-8 flex flex-col gap-4 sm:mb-12 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <span className="font-display text-xs font-semibold uppercase tracking-[0.3em] text-primary-glow">
              All Channels
            </span>
            <h2 className="mt-2 font-display text-3xl font-black uppercase tracking-tight sm:text-5xl">
              <span className="text-foreground">Pick your </span>
              <span className="text-gradient">arena</span>
            </h2>
          </div>

          {/* Search */}
          <div className="relative w-full sm:w-72">
            <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search channels..."
              className="w-full rounded-full glass-card py-3 pl-11 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
        </div>

        {/* Category filter */}
        <div className="mb-8 flex flex-wrap gap-2 sm:mb-10">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={
                "rounded-full px-5 py-2 font-display text-xs font-semibold uppercase tracking-widest transition-all " +
                (activeCategory === cat
                  ? "gradient-violet text-white shadow-glow"
                  : "glass text-muted-foreground hover:text-foreground")
              }
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grid */}
        {filtered.length > 0 ? (
          <div
            key={`${activeCategory}-${query}`}
            className="stagger grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
          >
            {filtered.map((channel) => (
              <ChannelCard key={channel.id} channel={channel} />
            ))}
          </div>
        ) : (
          <div className="flex min-h-[300px] flex-col items-center justify-center rounded-3xl glass-card p-12 text-center">
            <Tv2 className="mb-4 h-12 w-12 text-muted-foreground/50" />
            <p className="font-display text-lg font-semibold text-foreground">No channels found</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Try a different search or category.
            </p>
          </div>
        )}
      </section>

      <footer className="border-t border-border/40 px-4 py-8 text-center sm:px-6">
        <p className="font-display text-xs uppercase tracking-[0.3em] text-muted-foreground">
          beIN Live · Premium Sports Streaming
        </p>
      </footer>
    </>
  );
}
