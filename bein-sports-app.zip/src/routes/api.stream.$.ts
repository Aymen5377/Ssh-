import { createFileRoute } from "@tanstack/react-router";

// Proxy HTTP m3u8 streams through this server route to avoid mixed-content
// blocking when the app is served over HTTPS. Rewrites .m3u8 playlists so all
// segment URLs route back through this proxy too.
type HandlerCtx = {
  request: Request;
  params: { _splat?: string };
};

export const Route = createFileRoute("/api/stream/$")({
  // @ts-expect-error - server handlers supported at runtime by TanStack Start
  server: {
    handlers: {
      GET: async ({ request, params }: HandlerCtx) => {
        const splat = params._splat ?? "";
        const url = new URL(request.url);
        const target = decodeURIComponent(splat) + url.search;

        if (!target.startsWith("http://") && !target.startsWith("https://")) {
          return new Response("Invalid target", { status: 400 });
        }

        try {
          const upstream = await fetch(target, {
            headers: {
              "User-Agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
              Accept: "*/*",
              Referer: new URL(target).origin + "/",
            },
          });

          if (!upstream.ok) {
            return new Response(`Upstream error ${upstream.status}`, {
              status: upstream.status,
            });
          }

          const contentType =
            upstream.headers.get("content-type") || "application/octet-stream";
          const isPlaylist =
            target.includes(".m3u8") ||
            contentType.includes("mpegurl") ||
            contentType.includes("vnd.apple");

          const baseHeaders: Record<string, string> = {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "*",
            "Access-Control-Expose-Headers": "*",
            "Cache-Control": "no-cache",
          };

          if (isPlaylist) {
            const text = await upstream.text();
            const targetUrl = new URL(target);
            const baseDir =
              targetUrl.origin +
              targetUrl.pathname.substring(0, targetUrl.pathname.lastIndexOf("/") + 1);

            const proxyPrefix = `${url.origin}/api/stream/`;

            const rewritten = text
              .split("\n")
              .map((line) => {
                const trimmed = line.trim();
                if (!trimmed || trimmed.startsWith("#")) {
                  // Rewrite URI="..." inside tags
                  return line.replace(/URI="([^"]+)"/g, (_m, uri: string) => {
                    const abs = uri.startsWith("http")
                      ? uri
                      : uri.startsWith("/")
                        ? targetUrl.origin + uri
                        : baseDir + uri;
                    return `URI="${proxyPrefix}${encodeURIComponent(abs)}"`;
                  });
                }
                const abs = trimmed.startsWith("http")
                  ? trimmed
                  : trimmed.startsWith("/")
                    ? targetUrl.origin + trimmed
                    : baseDir + trimmed;
                return `${proxyPrefix}${encodeURIComponent(abs)}`;
              })
              .join("\n");

            return new Response(rewritten, {
              status: 200,
              headers: {
                ...baseHeaders,
                "Content-Type": "application/vnd.apple.mpegurl",
              },
            });
          }

          // Stream segments directly
          return new Response(upstream.body, {
            status: 200,
            headers: {
              ...baseHeaders,
              "Content-Type": contentType,
            },
          });
        } catch (err) {
          const msg = err instanceof Error ? err.message : "Proxy error";
          return new Response(msg, { status: 502 });
        }
      },
      OPTIONS: async () => {
        return new Response(null, {
          status: 204,
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, OPTIONS",
            "Access-Control-Allow-Headers": "*",
          },
        });
      },
    },
  },
});
