export interface Channel {
  id: string;
  number: number;
  name: string;
  fullName: string;
  category: string;
  streamUrl: string;
  description: string;
  accent: string;
}

export const channels: Channel[] = [
  {
    id: "bein-1",
    number: 1,
    name: "beIN 1",
    fullName: "beIN Sports 1",
    category: "Premium",
    streamUrl: "http://103.205.17.67:8080/live/92164982129771/47825113539654/66.m3u8",
    description: "Premier League · Champions League",
    accent: "from-violet-500 to-purple-700",
  },
  {
    id: "bein-2",
    number: 2,
    name: "beIN 2",
    fullName: "beIN Sports 2",
    category: "Premium",
    streamUrl: "http://103.205.17.67:8080/live/92164982129771/47825113539654/65.m3u8",
    description: "La Liga · Top Football",
    accent: "from-fuchsia-500 to-violet-700",
  },
  {
    id: "bein-3",
    number: 3,
    name: "beIN 3",
    fullName: "beIN Sports 3",
    category: "Premium",
    streamUrl: "http://103.205.17.67:8080/live/92164982129771/47825113539654/64.m3u8",
    description: "Serie A · Bundesliga",
    accent: "from-purple-500 to-indigo-700",
  },
  {
    id: "bein-4",
    number: 4,
    name: "beIN 4",
    fullName: "beIN Sports 4",
    category: "HD",
    streamUrl: "http://103.205.17.67:8080/live/92164982129771/47825113539654/73.m3u8",
    description: "Ligue 1 · European Cups",
    accent: "from-violet-600 to-purple-800",
  },
  {
    id: "bein-5",
    number: 5,
    name: "beIN 5",
    fullName: "beIN Sports 5",
    category: "HD",
    streamUrl: "http://103.205.17.67:8080/live/92164982129771/47825113539654/72.m3u8",
    description: "Live Matches · Highlights",
    accent: "from-purple-600 to-fuchsia-700",
  },
  {
    id: "bein-6",
    number: 6,
    name: "beIN 6",
    fullName: "beIN Sports 6",
    category: "HD",
    streamUrl: "http://103.205.17.67:8080/live/92164982129771/47825113539654/71.m3u8",
    description: "Tennis · ATP · WTA",
    accent: "from-indigo-500 to-purple-700",
  },
  {
    id: "bein-7",
    number: 7,
    name: "beIN 7",
    fullName: "beIN Sports 7",
    category: "HD",
    streamUrl: "http://103.205.17.67:8080/live/92164982129771/47825113539654/70.m3u8",
    description: "Basketball · NBA · EuroLeague",
    accent: "from-violet-700 to-fuchsia-600",
  },
  {
    id: "bein-8",
    number: 8,
    name: "beIN 8",
    fullName: "beIN Sports 8",
    category: "HD",
    streamUrl: "http://103.205.17.67:8080/live/92164982129771/47825113539654/69.m3u8",
    description: "Motor Sports · Formula 1",
    accent: "from-fuchsia-600 to-violet-800",
  },
  {
    id: "bein-9",
    number: 9,
    name: "beIN 9",
    fullName: "beIN Sports 9",
    category: "HD",
    streamUrl: "http://103.205.17.67:8080/live/92164982129771/47825113539654/68.m3u8",
    description: "Combat Sports · UFC · Boxing",
    accent: "from-purple-700 to-indigo-600",
  },
];

export function getChannelById(id: string): Channel | undefined {
  return channels.find((c) => c.id === id);
}
