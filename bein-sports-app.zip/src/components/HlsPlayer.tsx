import { useEffect, useRef, useState, useCallback } from "react";
import Hls from "hls.js";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  Loader2,
  RotateCcw,
  PictureInPicture2,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface HlsPlayerProps {
  src: string;
  poster?: string;
  title?: string;
  autoPlay?: boolean;
}

function isCapacitorNative(): boolean {
  if (typeof window === "undefined") return false;
  // @ts-expect-error - Capacitor injects this global at runtime in native apps
  return !!(window.Capacitor && window.Capacitor.isNativePlatform?.());
}

function buildProxyUrl(original: string): string {
  if (typeof window === "undefined") return original;
  // In native APK (Capacitor) HTTP works directly — skip proxy for speed
  if (isCapacitorNative()) return original;
  // If page is HTTPS and source is HTTP, proxy it through our server
  if (window.location.protocol === "https:" && original.startsWith("http://")) {
    return `/api/stream/${encodeURIComponent(original)}`;
  }
  return original;
}

export function HlsPlayer({ src, poster, title, autoPlay = true }: HlsPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const hideControlsTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showControls, setShowControls] = useState(true);
  const [retryCount, setRetryCount] = useState(0);

  const loadStream = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    setIsLoading(true);
    setError(null);

    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    const proxiedSrc = buildProxyUrl(src);

    if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = proxiedSrc;
      if (autoPlay) {
        video.play().catch(() => {});
      }
      return;
    }

    if (Hls.isSupported()) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: false,
        maxBufferLength: 30,
        maxMaxBufferLength: 60,
      });
      hlsRef.current = hls;

      hls.loadSource(proxiedSrc);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        setIsLoading(false);
        if (autoPlay) {
          video.play().catch(() => {});
        }
      });

      hls.on(Hls.Events.ERROR, (_event, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              setError("Network error — retrying...");
              setTimeout(() => hls.startLoad(), 2000);
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              hls.recoverMediaError();
              break;
            default:
              setError("Stream unavailable. Try another channel.");
              hls.destroy();
              break;
          }
        }
      });
    } else {
      setError("Your browser does not support HLS playback.");
    }
  }, [src, autoPlay]);

  useEffect(() => {
    loadStream();
    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [loadStream, retryCount]);

  // Sync video state -> UI state
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);
    const onWaiting = () => setIsLoading(true);
    const onPlaying = () => setIsLoading(false);
    const onVolumeChange = () => {
      setIsMuted(video.muted);
      setVolume(video.volume);
    };

    video.addEventListener("play", onPlay);
    video.addEventListener("pause", onPause);
    video.addEventListener("waiting", onWaiting);
    video.addEventListener("playing", onPlaying);
    video.addEventListener("volumechange", onVolumeChange);

    return () => {
      video.removeEventListener("play", onPlay);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("waiting", onWaiting);
      video.removeEventListener("playing", onPlaying);
      video.removeEventListener("volumechange", onVolumeChange);
    };
  }, []);

  // Fullscreen tracking
  useEffect(() => {
    const handler = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", handler);
    return () => document.removeEventListener("fullscreenchange", handler);
  }, []);

  // Auto-hide controls
  const resetHideTimer = useCallback(() => {
    setShowControls(true);
    if (hideControlsTimer.current) clearTimeout(hideControlsTimer.current);
    hideControlsTimer.current = setTimeout(() => {
      if (videoRef.current && !videoRef.current.paused) {
        setShowControls(false);
      }
    }, 3000);
  }, []);

  useEffect(() => {
    resetHideTimer();
    return () => {
      if (hideControlsTimer.current) clearTimeout(hideControlsTimer.current);
    };
  }, [resetHideTimer]);

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) video.play().catch(() => {});
    else video.pause();
    resetHideTimer();
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !video.muted;
    resetHideTimer();
  };

  const handleVolume = (e: React.ChangeEvent<HTMLInputElement>) => {
    const video = videoRef.current;
    if (!video) return;
    const v = parseFloat(e.target.value);
    video.volume = v;
    video.muted = v === 0;
  };

  const toggleFullscreen = async () => {
    const el = containerRef.current;
    if (!el) return;
    try {
      if (!document.fullscreenElement) {
        await el.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
    } catch {
      /* ignore */
    }
  };

  const togglePip = async () => {
    const video = videoRef.current;
    if (!video) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else if (document.pictureInPictureEnabled) {
        await video.requestPictureInPicture();
      }
    } catch {
      /* ignore */
    }
  };

  const retry = () => {
    setRetryCount((c) => c + 1);
  };

  return (
    <div
      ref={containerRef}
      className="group relative aspect-video w-full overflow-hidden rounded-2xl bg-black shadow-elevated"
      onMouseMove={resetHideTimer}
      onMouseLeave={() => {
        if (videoRef.current && !videoRef.current.paused) setShowControls(false);
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget || (e.target as HTMLElement).tagName === "VIDEO") {
          togglePlay();
        }
      }}
    >
      <video
        ref={videoRef}
        className="h-full w-full object-contain"
        poster={poster}
        playsInline
        autoPlay={autoPlay}
      />

      {/* Loading overlay */}
      {isLoading && !error && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-sm animate-fade-in">
          <div className="flex flex-col items-center gap-3">
            <Loader2 className="h-12 w-12 animate-spin text-primary-glow drop-shadow-[0_0_20px_oklch(0.72_0.27_305)]" />
            <span className="font-display text-sm uppercase tracking-widest text-primary-glow">
              Loading Stream
            </span>
          </div>
        </div>
      )}

      {/* Error overlay */}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/70 backdrop-blur-md">
          <div className="flex flex-col items-center gap-4 px-6 text-center">
            <p className="font-display text-lg text-destructive">{error}</p>
            <button
              onClick={retry}
              className="flex items-center gap-2 rounded-full bg-primary px-6 py-2.5 font-medium text-primary-foreground transition-all hover:bg-primary-glow hover:shadow-glow"
            >
              <RotateCcw className="h-4 w-4" />
              Retry
            </button>
          </div>
        </div>
      )}

      {/* Top bar */}
      <div
        className={cn(
          "pointer-events-none absolute left-0 right-0 top-0 flex items-center justify-between bg-gradient-to-b from-black/80 via-black/40 to-transparent px-4 py-3 transition-opacity duration-300 sm:px-6 sm:py-4",
          showControls ? "opacity-100" : "opacity-0",
        )}
      >
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-2 rounded-full bg-live/90 px-3 py-1 font-display text-xs font-bold uppercase tracking-widest text-white shadow-lg">
            <span className="h-1.5 w-1.5 rounded-full bg-white animate-live-pulse" />
            Live
          </span>
          {title && (
            <span className="font-display text-sm font-semibold uppercase tracking-wider text-white drop-shadow-lg sm:text-base">
              {title}
            </span>
          )}
        </div>
      </div>

      {/* Center play button when paused */}
      {!isPlaying && !isLoading && !error && (
        <button
          onClick={togglePlay}
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/90 p-6 shadow-glow-lg backdrop-blur-sm transition-all hover:scale-110 hover:bg-primary-glow animate-scale-in"
          aria-label="Play"
        >
          <Play className="h-8 w-8 fill-white text-white" />
        </button>
      )}

      {/* Bottom controls */}
      <div
        className={cn(
          "absolute bottom-0 left-0 right-0 flex items-center gap-2 bg-gradient-to-t from-black/90 via-black/60 to-transparent px-3 py-3 transition-all duration-300 sm:gap-3 sm:px-6 sm:py-5",
          showControls ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2 pointer-events-none",
        )}
      >
        <button
          onClick={togglePlay}
          className="rounded-full p-2 text-white transition-all hover:scale-110 hover:bg-white/10 hover:text-primary-glow"
          aria-label={isPlaying ? "Pause" : "Play"}
        >
          {isPlaying ? <Pause className="h-5 w-5 sm:h-6 sm:w-6" /> : <Play className="h-5 w-5 sm:h-6 sm:w-6" />}
        </button>

        <div className="group/vol flex items-center gap-2">
          <button
            onClick={toggleMute}
            className="rounded-full p-2 text-white transition-all hover:scale-110 hover:bg-white/10 hover:text-primary-glow"
            aria-label={isMuted ? "Unmute" : "Mute"}
          >
            {isMuted || volume === 0 ? (
              <VolumeX className="h-5 w-5" />
            ) : (
              <Volume2 className="h-5 w-5" />
            )}
          </button>
          <input
            type="range"
            min={0}
            max={1}
            step={0.05}
            value={isMuted ? 0 : volume}
            onChange={handleVolume}
            className="hidden h-1 w-0 cursor-pointer appearance-none rounded-full bg-white/20 accent-primary-glow transition-all duration-300 group-hover/vol:w-20 sm:inline-block sm:group-hover/vol:w-24"
            style={{
              background: `linear-gradient(to right, oklch(0.72 0.27 305) 0%, oklch(0.72 0.27 305) ${(isMuted ? 0 : volume) * 100}%, oklch(1 0 0 / 0.2) ${(isMuted ? 0 : volume) * 100}%, oklch(1 0 0 / 0.2) 100%)`,
            }}
          />
        </div>

        <div className="ml-auto flex items-center gap-1 sm:gap-2">
          <button
            onClick={togglePip}
            className="hidden rounded-full p-2 text-white transition-all hover:scale-110 hover:bg-white/10 hover:text-primary-glow sm:block"
            aria-label="Picture in Picture"
          >
            <PictureInPicture2 className="h-5 w-5" />
          </button>
          <button
            onClick={toggleFullscreen}
            className="rounded-full p-2 text-white transition-all hover:scale-110 hover:bg-white/10 hover:text-primary-glow"
            aria-label={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
          >
            {isFullscreen ? (
              <Minimize className="h-5 w-5 sm:h-6 sm:w-6" />
            ) : (
              <Maximize className="h-5 w-5 sm:h-6 sm:w-6" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
