import { Link } from "@tanstack/react-router";
import { Play } from "lucide-react";
import type { Channel } from "@/lib/channels";
import { cn } from "@/lib/utils";

interface ChannelCardProps {
  channel: Channel;
}

export function ChannelCard({ channel }: ChannelCardProps) {
  return (
    <Link
      to="/channel/$channelId"
      params={{ channelId: channel.id }}
      className="group relative block overflow-hidden rounded-2xl glass-card hover-lift bg-noise"
    >
      {/* Gradient halo on hover */}
      <div
        className={cn(
          "pointer-events-none absolute -inset-px rounded-2xl bg-gradient-to-br opacity-0 blur-xl transition-opacity duration-500 group-hover:opacity-60",
          channel.accent,
        )}
      />

      <div className="relative flex aspect-[4/3] flex-col p-5">
        {/* Top: number + live badge */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2 rounded-full bg-live/15 px-2.5 py-1 ring-1 ring-live/30">
            <span className="live-dot" />
            <span className="font-display text-[10px] font-bold uppercase tracking-[0.2em] text-live">
              Live
            </span>
          </div>
          <span className="font-display text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            {channel.category}
          </span>
        </div>

        {/* Center: Big channel number */}
        <div className="flex flex-1 items-center justify-center">
          <div className="relative">
            <span
              className={cn(
                "font-display text-7xl font-black leading-none tracking-tighter bg-gradient-to-br bg-clip-text text-transparent drop-shadow-[0_0_30px_oklch(0.72_0.27_305_/_0.4)] sm:text-8xl",
                channel.accent,
              )}
            >
              {String(channel.number).padStart(2, "0")}
            </span>
            <div
              className={cn(
                "absolute inset-0 -z-10 bg-gradient-to-br opacity-30 blur-2xl",
                channel.accent,
              )}
            />
          </div>
        </div>

        {/* Bottom: name + play */}
        <div className="flex items-end justify-between gap-3">
          <div className="min-w-0 flex-1">
            <h3 className="font-display text-base font-bold uppercase tracking-wider text-foreground sm:text-lg">
              {channel.fullName}
            </h3>
            <p className="mt-0.5 truncate text-xs text-muted-foreground">
              {channel.description}
            </p>
          </div>
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full gradient-violet shadow-glow transition-all duration-300 group-hover:scale-110 group-hover:shadow-glow-lg">
            <Play className="h-4 w-4 fill-white text-white translate-x-0.5" />
          </div>
        </div>
      </div>
    </Link>
  );
}
