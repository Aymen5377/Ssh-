import { Link, useRouterState } from "@tanstack/react-router";
import { Tv, Radio, Calendar } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { to: "/", label: "Channels", icon: Tv, exact: true },
  { to: "/matches", label: "Live Matches", icon: Calendar, exact: false },
];

export function Header() {
  const { location } = useRouterState();

  return (
    <header className="sticky top-0 z-40 border-b border-border/40 bg-background/60 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:h-20 sm:px-6 lg:px-8">
        <Link to="/" className="group flex items-center gap-3">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl gradient-violet shadow-glow transition-transform group-hover:scale-110">
            <Radio className="h-5 w-5 text-white" />
            <div className="absolute inset-0 rounded-xl gradient-violet opacity-0 blur-xl transition-opacity group-hover:opacity-70" />
          </div>
          <div className="flex flex-col leading-none">
            <span className="font-display text-lg font-black uppercase tracking-wider text-gradient sm:text-xl">
              beIN Live
            </span>
            <span className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground sm:text-xs">
              Premium Sports
            </span>
          </div>
        </Link>

        <nav className="flex items-center gap-1 sm:gap-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = item.exact
              ? location.pathname === item.to
              : location.pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "group relative flex items-center gap-2 rounded-full px-3 py-2 font-display text-xs font-semibold uppercase tracking-wider transition-all sm:px-5 sm:py-2.5 sm:text-sm",
                  active
                    ? "text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                {active && (
                  <span className="absolute inset-0 rounded-full gradient-violet shadow-glow" />
                )}
                <Icon className="relative h-4 w-4" />
                <span className="relative hidden sm:inline">{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
